package com.doit.json.rate.parse;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class Test {
	public static void main(String[] args) throws Exception {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("d:/rating.json"), "UTF-8"));
		
		String line = br.readLine();
		
		MoiveRate mrObj = MoiveRateLogParse.parseLine(line);
		
		System.out.println(mrObj.getMovie());
		System.out.println(mrObj.getRate());
		System.out.println(mrObj.getTimeStamp());
		System.out.println(mrObj.getUid());
		
		
	}

}
