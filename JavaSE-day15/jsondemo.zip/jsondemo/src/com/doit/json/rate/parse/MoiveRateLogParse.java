package com.doit.json.rate.parse;

import com.google.gson.Gson;

public class MoiveRateLogParse {
	
	public static MoiveRate parseLine(String line) {
		
		Gson gson = new Gson();
		MoiveRate moiveRate = gson.fromJson(line, MoiveRate.class);
		
		
		/*MoiveRate m2 = new MoiveRate();
		m2.setMovie("xxx");
		String json = gson.toJson(m2);*/
		
		return moiveRate;
		
	}

}
